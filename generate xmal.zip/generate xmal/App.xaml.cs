﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace generate_xmal
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
