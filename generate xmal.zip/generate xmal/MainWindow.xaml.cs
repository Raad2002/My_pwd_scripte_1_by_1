﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Linq;

namespace generate_xmal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnInstallApp_Click(object sender, RoutedEventArgs e)
        {
            // Ouvre l'interface InstallAppWindow
            var appWindow = new generate_xmal.InstallAppWindow();
            appWindow.Owner = this;
            appWindow.ShowDialog();
        }

        private void btnInstallOffice_Click(object sender, RoutedEventArgs e)
        {
            // Ouvre l'interface InstallOfficeWindow
            var officeWindow = new InstallOfficeWindow();
            officeWindow.Owner = this;
            officeWindow.ShowDialog();
        }



    }


}

namespace generate_xmal
{
    public partial class InstallAppWindow : Window
    {
        public InstallAppWindow()
        {
            InitializeComponent();
        }
    }
}



namespace generate_xmal
{
    public partial class InstallOfficeWindow : Window
    {
        public InstallOfficeWindow()
        {
            InitializeComponent();
        }
    }
}